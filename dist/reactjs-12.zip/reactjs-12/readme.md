## React JS version

This is the production build version 12 for https://github.com/kyledinh/pwa/tree/master/react-app

## To run and preview this build

Run a local webserver like https://www.npmjs.com/package/http-server

* `npm install http-server -g`
* `http-server` in this directory
* Browse to `http://127.0.0.1:8080/`

## Screenshot

<img src="./screen-shot.png" width="80%" />
